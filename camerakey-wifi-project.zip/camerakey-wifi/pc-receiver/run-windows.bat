@echo off
setlocal
if "%CAMERAKEY_TOKEN%"=="" set /p CAMERAKEY_TOKEN=Enter a shared token: 
py -m pip install -r requirements.txt
py receiver.py
pause
