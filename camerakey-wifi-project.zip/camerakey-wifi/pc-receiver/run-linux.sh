#!/usr/bin/env bash
set -euo pipefail
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if [[ -z "${CAMERAKEY_TOKEN:-}" ]]; then
  read -rsp "Enter a shared token: " CAMERAKEY_TOKEN
  echo
  export CAMERAKEY_TOKEN
fi
python receiver.py
