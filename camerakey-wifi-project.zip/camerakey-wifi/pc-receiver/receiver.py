#!/usr/bin/env python3
"""CameraKey WiFi receiver. Receives authenticated key-down/up events over LAN."""
import argparse
import asyncio
import json
import os
import socket
import sys
from typing import Any

import websockets
from pynput.keyboard import Controller, Key

keyboard = Controller()
held: dict[str, Any] = {}

SPECIAL = {
    "SPACE": Key.space, "ENTER": Key.enter, "RETURN": Key.enter,
    "TAB": Key.tab, "BACKSPACE": Key.backspace, "DELETE": Key.delete,
    "ESC": Key.esc, "ESCAPE": Key.esc, "UP": Key.up, "DOWN": Key.down,
    "LEFT": Key.left, "RIGHT": Key.right, "HOME": Key.home,
    "END": Key.end, "PAGEUP": Key.page_up, "PAGEDOWN": Key.page_down,
    "SHIFT": Key.shift, "CTRL": Key.ctrl, "CONTROL": Key.ctrl,
    "ALT": Key.alt, "CAPSLOCK": Key.caps_lock, "INSERT": Key.insert,
    "F1": Key.f1, "F2": Key.f2, "F3": Key.f3, "F4": Key.f4,
    "F5": Key.f5, "F6": Key.f6, "F7": Key.f7, "F8": Key.f8,
    "F9": Key.f9, "F10": Key.f10, "F11": Key.f11, "F12": Key.f12,
}


def resolve_key(label: str):
    name = label.strip().upper()
    if name in SPECIAL:
        return SPECIAL[name]
    if len(name) == 1:
        # Keycaps are labelled uppercase; ordinary letter presses should type lowercase.
        return name.lower() if name.isalpha() else name
    raise ValueError(f"Unsupported key label: {label}")


def release_everything() -> None:
    for label, key in list(held.items()):
        try:
            keyboard.release(key)
        except Exception:
            pass
        held.pop(label, None)


async def handle_client(websocket, path=None, *, token: str):
    authenticated = False
    client_name = getattr(websocket, "remote_address", "unknown")
    print(f"[+] Client connected: {client_name}")
    try:
        async for raw in websocket:
            try:
                message = json.loads(raw)
            except json.JSONDecodeError:
                await websocket.send(json.dumps({"error": "invalid_json"}))
                continue

            if not authenticated:
                if message.get("type") == "auth" and message.get("token") == token:
                    authenticated = True
                    await websocket.send(json.dumps({"status": "authenticated"}))
                    print(f"[+] Authenticated: {client_name}")
                else:
                    await websocket.send(json.dumps({"error": "authentication_failed"}))
                    await websocket.close(code=4001, reason="Authentication failed")
                    break
                continue

            if message.get("type") != "key":
                continue
            label = str(message.get("key", "")).strip().upper()
            down = message.get("down")
            if not label or len(label) > 12 or not isinstance(down, bool):
                continue
            try:
                key = resolve_key(label)
                if down and label not in held:
                    keyboard.press(key)
                    held[label] = key
                    print(f"DOWN {label}")
                elif not down and label in held:
                    keyboard.release(held.pop(label))
                    print(f"UP   {label}")
            except (ValueError, RuntimeError, OSError) as exc:
                await websocket.send(json.dumps({"error": str(exc)}))
    except websockets.ConnectionClosed:
        pass
    finally:
        # Release any key left held if the phone disconnects.
        release_everything()
        print(f"[-] Client disconnected: {client_name}")


def local_ip() -> str:
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.connect(("8.8.8.8", 80))
        return sock.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        sock.close()


async def main():
    parser = argparse.ArgumentParser(description="CameraKey WiFi PC keyboard receiver")
    parser.add_argument("--host", default="0.0.0.0", help="Interface to listen on (default: all LAN interfaces)")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--token", default=os.environ.get("CAMERAKEY_TOKEN"), help="Shared secret; preferably set CAMERAKEY_TOKEN")
    args = parser.parse_args()
    if not args.token:
        print("ERROR: Set CAMERAKEY_TOKEN or pass --token. Do not use an empty token.", file=sys.stderr)
        raise SystemExit(2)

    print("CameraKey WiFi receiver")
    print(f"Listening: ws://{local_ip()}:{args.port}")
    print("Enter this IP and the same shared token in the Android app.")
    print("Keep both devices on the same trusted Wi-Fi network. Press Ctrl+C to stop.")
    async with websockets.serve(lambda ws, path=None: handle_client(ws, path, token=args.token), args.host, args.port, ping_interval=20, ping_timeout=20, max_size=4096):
        await asyncio.Future()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        release_everything()
        print("\nReceiver stopped.")
