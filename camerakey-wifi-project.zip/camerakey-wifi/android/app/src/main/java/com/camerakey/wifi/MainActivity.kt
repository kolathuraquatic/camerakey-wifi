package com.camerakey.wifi

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.java_websocket.client.WebSocketClient
import org.java_websocket.handshake.ServerHandshake
import org.json.JSONObject
import java.net.URI
import java.nio.ByteBuffer
import java.util.concurrent.Executors
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.math.max
import kotlin.math.min

private data class KeyRegion(
    val label: String,
    val x: Float,
    val y: Float,
    @Volatile var pressed: Boolean = false
)

class MainActivity : AppCompatActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var overlay: KeyOverlay
    private lateinit var status: TextView
    private lateinit var ipInput: EditText
    private lateinit var tokenInput: EditText
    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private val keys = CopyOnWriteArrayList<KeyRegion>()
    @Volatile private var baseline: ByteArray? = null
    @Volatile private var frameWidth = 0
    @Volatile private var frameHeight = 0
    @Volatile private var captureBaseline = false
    @Volatile private var detectionEnabled = false
    @Volatile private var addKeyMode = false
    private var socket: WebSocketClient? = null
    private var lastStatus = "Camera not started"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
        buildUi()
        loadCalibration()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 10)
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(244,247,251)) }
        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(8, 5, 8, 5)
        }
        ipInput = EditText(this).apply { hint = "PC IP (e.g. 192.168.1.10)"; setSingleLine(); textSize = 12f; setText("192.168.1.10"); minWidth = dp(155) }
        tokenInput = EditText(this).apply { hint = "Shared token"; setSingleLine(); textSize = 12f; setText("change-this-token"); minWidth = dp(125) }
        controls.addView(ipInput, LinearLayout.LayoutParams(dp(165), dp(44)))
        controls.addView(tokenInput, LinearLayout.LayoutParams(dp(145), dp(44)))
        controls.addView(makeButton("Connect") { connectSocket() })
        controls.addView(makeButton("Capture baseline") {
            detectionEnabled = false
            keys.forEach { it.pressed = false }
            captureBaseline = true
            setStatus("Capturing clear keyboard image… keep hands away")
        })
        controls.addView(makeButton("Add key") {
            addKeyMode = true
            setStatus("Tap the centre of a key in the camera view")
        })
        controls.addView(makeButton("Detect: OFF") {
            detectionEnabled = !detectionEnabled
            (it as Button).text = if (detectionEnabled) "Detect: ON" else "Detect: OFF"
            setStatus(if (detectionEnabled) "Detection running" else "Detection paused")
        })
        controls.addView(makeButton("Clear") {
            releaseAllKeys(); keys.clear(); baseline = null; saveCalibration(); overlay.invalidate()
            setStatus("Calibration cleared")
        })
        status = TextView(this).apply { text = lastStatus; textSize = 12f; setTextColor(Color.DKGRAY); setPadding(10,0,4,0) }
        controls.addView(status, LinearLayout.LayoutParams(0, dp(44), 1f))
        root.addView(controls, LinearLayout.LayoutParams(-1, dp(54)))

        val cameraFrame = FrameLayout(this)
        previewView = PreviewView(this).apply { scaleType = PreviewView.ScaleType.FIT_CENTER; implementationMode = PreviewView.ImplementationMode.COMPATIBLE }
        overlay = KeyOverlay()
        cameraFrame.addView(previewView, FrameLayout.LayoutParams(-1, -1))
        cameraFrame.addView(overlay, FrameLayout.LayoutParams(-1, -1))
        root.addView(cameraFrame, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun makeButton(label: String, action: (View) -> Unit): Button = Button(this).apply {
        text = label; textSize = 10f; isAllCaps = false; setPadding(dp(5), 0, dp(5), 0)
        setOnClickListener(action)
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun setStatus(message: String) { runOnUiThread { lastStatus = message; if (::status.isInitialized) status.text = message } }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()
            val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
            val analysis = ImageAnalysis.Builder()
                .setTargetResolution(android.util.Size(1280, 720))
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
            analysis.setAnalyzer(cameraExecutor) { image -> analyzeFrame(image) }
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
                setStatus("Camera ready · mount phone and keep it still")
            } catch (e: Exception) { setStatus("Camera error: ${e.message}") }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyzeFrame(image: ImageProxy) {
        try {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val width = image.width
            val height = image.height
            val rowStride = plane.rowStride
            val pixelStride = plane.pixelStride
            val gray = ByteArray(width * height)
            for (y in 0 until height) {
                val rowStart = y * rowStride
                for (x in 0 until width) gray[y * width + x] = buffer.get(rowStart + x * pixelStride)
            }
            frameWidth = width; frameHeight = height
            if (captureBaseline) {
                baseline = gray
                captureBaseline = false
                runOnUiThread { overlay.invalidate() }
                setStatus("Baseline saved · ${keys.size} calibrated keys")
            }
            if (detectionEnabled) {
                val base = baseline
                if (base == null || base.size != gray.size) {
                    detectionEnabled = false
                    setStatus("Capture a baseline before detection")
                } else {
                    detectKeys(gray, base, width, height)
                }
            }
        } catch (e: Exception) {
            setStatus("Frame error: ${e.message}")
        } finally { image.close() }
    }

    private fun detectKeys(current: ByteArray, base: ByteArray, width: Int, height: Int) {
        val radius = max(7, (width * 0.014f).toInt())
        for (key in keys) {
            val cx = (key.x * width).toInt().coerceIn(radius, width - radius - 1)
            val cy = (key.y * height).toInt().coerceIn(radius, height - radius - 1)
            var changed = 0; var total = 0; var difference = 0L
            var y = max(0, cy-radius)
            while (y <= min(height-1, cy+radius)) {
                var x = max(0, cx-radius)
                while (x <= min(width-1, cx+radius)) {
                    val dx = x-cx; val dy = y-cy
                    if (dx*dx + dy*dy <= radius*radius) {
                        val idx = y*width+x
                        val d = kotlin.math.abs((current[idx].toInt() and 0xff) - (base[idx].toInt() and 0xff))
                        difference += d
                        if (d > 28) changed++
                        total++
                    }
                    x++
                }
                y++
            }
            if (total == 0) continue
            val changedRatio = changed.toFloat()/total
            val meanDiff = difference.toFloat()/total
            val nowPressed = if (key.pressed) (changedRatio > 0.13f && meanDiff > 11f)
                             else (changedRatio > 0.31f && meanDiff > 20f)
            if (nowPressed != key.pressed) {
                key.pressed = nowPressed
                sendKey(key.label, nowPressed)
                runOnUiThread { overlay.invalidate() }
            }
        }
    }

    private fun connectSocket() {
        try {
            socket?.close()
            val host = ipInput.text.toString().trim()
            val token = tokenInput.text.toString()
            val uri = URI("ws://$host:8765")
            val client = object : WebSocketClient(uri) {
                override fun onOpen(handshakedata: ServerHandshake?) {
                    send(JSONObject().put("type", "auth").put("token", token).toString())
                    setStatus("Connected · authenticating…")
                }
                override fun onMessage(message: String?) {
                    val msg = message ?: return
                    setStatus(if (msg.contains("authenticated")) "Connected · PC ready" else msg.take(70))
                }
                override fun onClose(code: Int, reason: String?, remote: Boolean) { setStatus("Disconnected: ${reason ?: code}") }
                override fun onError(ex: Exception?) { setStatus("Wi-Fi error: ${ex?.message}") }
            }
            socket = client
            client.connect()
            setStatus("Connecting to $host…")
        } catch (e: Exception) { setStatus("Connection error: ${e.message}") }
    }

    private fun sendKey(label: String, down: Boolean) {
        val client = socket
        if (client?.isOpen == true) {
            try { client.send(JSONObject().put("type", "key").put("key", label).put("down", down).toString()) }
            catch (_: Exception) { setStatus("Could not send key event") }
        }
    }

    private fun releaseAllKeys() { keys.filter { it.pressed }.forEach { it.pressed = false; sendKey(it.label, false) } }

    private fun saveCalibration() {
        val array = org.json.JSONArray()
        keys.forEach { key ->
            array.put(JSONObject().put("label", key.label).put("x", key.x.toDouble()).put("y", key.y.toDouble()))
        }
        getSharedPreferences("camerakey", MODE_PRIVATE).edit().putString("keys", array.toString()).apply()
    }

    private fun loadCalibration() {
        val raw = getSharedPreferences("camerakey", MODE_PRIVATE).getString("keys", null) ?: return
        try {
            val array = org.json.JSONArray(raw)
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                keys.add(KeyRegion(item.getString("label"), item.getDouble("x").toFloat(), item.getDouble("y").toFloat()))
            }
            setStatus("Loaded ${keys.size} calibrated keys · capture a fresh baseline")
        } catch (_: Exception) {
            keys.clear()
            setStatus("Saved calibration could not be read; please recalibrate")
        }
    }

    private fun fittedImageRect(): android.graphics.RectF {
        val vw = overlay.width.toFloat(); val vh = overlay.height.toFloat()
        val iw = if (frameWidth > 0) frameWidth.toFloat() else 16f
        val ih = if (frameHeight > 0) frameHeight.toFloat() else 9f
        val scale = min(vw/iw, vh/ih)
        val w = iw*scale; val h = ih*scale
        return android.graphics.RectF((vw-w)/2f, (vh-h)/2f, (vw+w)/2f, (vh+h)/2f)
    }

    private inner class KeyOverlay : View(this@MainActivity) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        init { setOnTouchListener { _, event ->
            if (event.action == android.view.MotionEvent.ACTION_UP && addKeyMode) {
                val rect = fittedImageRect()
                if (rect.contains(event.x, event.y)) {
                    val nx = ((event.x-rect.left)/rect.width()).coerceIn(0f,1f)
                    val ny = ((event.y-rect.top)/rect.height()).coerceIn(0f,1f)
                    askKeyLabel(nx, ny)
                }
                true
            } else false
        } }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val rect = fittedImageRect()
            for (key in keys) {
                val x = rect.left + key.x*rect.width(); val y = rect.top + key.y*rect.height()
                paint.color = if (key.pressed) Color.rgb(30,190,90) else Color.rgb(30,120,230)
                paint.style = Paint.Style.STROKE; paint.strokeWidth = 3f
                canvas.drawCircle(x,y, max(12f, rect.width()*0.014f), paint)
                paint.style = Paint.Style.FILL; paint.textSize = 22f; paint.textAlign = Paint.Align.CENTER
                canvas.drawText(key.label,x,y-20f,paint)
            }
        }
    }

    private fun askKeyLabel(x: Float, y: Float) {
        val input = EditText(this).apply { hint = "Key label (e.g. A, SPACE, ENTER)"; setSingleLine(); filters = arrayOf(android.text.InputFilter.LengthFilter(12)) }
        android.app.AlertDialog.Builder(this)
            .setTitle("Calibrate key")
            .setMessage("Tap was saved at this camera position. Enter the printed key label.")
            .setView(input)
            .setPositiveButton("Add") { _, _ ->
                val label = input.text.toString().trim().uppercase()
                if (label.isNotEmpty()) { keys.add(KeyRegion(label,x,y)); saveCalibration(); overlay.invalidate(); setStatus("Added $label · ${keys.size} keys calibrated") }
                addKeyMode = false
            }
            .setNegativeButton("Cancel") { _, _ -> addKeyMode = false }
            .show()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 10 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startCamera()
        else setStatus("Camera permission is required")
    }

    override fun onDestroy() {
        detectionEnabled = false
        releaseAllKeys()
        socket?.close()
        cameraExecutor.shutdown()
        super.onDestroy()
    }
}
